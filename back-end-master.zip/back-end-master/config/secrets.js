module.exports = {  
    jwtSecret: process.env.JWT_SECRET || 'Who calls a secret a secret'
}